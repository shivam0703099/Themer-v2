/**
 * Revenge Plugin Settings UI (React Native)
 * Built with React.createElement + ReactNative primitives so it runs reliably
 * across Discord Android versions without breaking on internal FormRow changes.
 */

import { React, ReactNative, clipboard } from "@vendetta/metro/common";
import { storage } from "@vendetta/plugin";
import { useProxy } from "@vendetta/storage";
import { showToast } from "@vendetta/ui/toasts";
import { parseBdVencordCss } from "../parser/cssParser";
import { mapCssThemeToRevenge } from "../mapper/themeMapper";
import {
  applyLiveTheme,
  clearLiveTheme,
  exportRevengeThemeJson,
  tryApplyNativeRevengeTheme,
  type SavedThemeEntry,
} from "../engine/themeEngine";

const {
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Switch,
  ActivityIndicator,
  StyleSheet,
} = ReactNative;

const h = React.createElement;

export interface PluginStorage {
  themes: SavedThemeEntry[];
  activeThemeId: string | null;
  followImports: boolean;
  autoDerive: boolean;
  livePatch: boolean;
}

export function initDefaultStorage(): PluginStorage {
  const s = storage as unknown as PluginStorage;
  if (!Array.isArray(s.themes)) s.themes = [];
  if (typeof s.activeThemeId !== "string" && s.activeThemeId !== null) s.activeThemeId = null;
  if (typeof s.followImports !== "boolean") s.followImports = true;
  if (typeof s.autoDerive !== "boolean") s.autoDerive = true;
  if (typeof s.livePatch !== "boolean") s.livePatch = true;
  return s;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 14,
  },
  card: {
    backgroundColor: "rgba(128, 128, 140, 0.14)",
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
  },
  heading: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
    marginBottom: 6,
  },
  subtext: {
    fontSize: 12,
    color: "#B5BAC1",
    marginBottom: 10,
    lineHeight: 17,
  },
  input: {
    backgroundColor: "rgba(0, 0, 0, 0.28)",
    color: "#FFFFFF",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 13,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.12)",
  },
  multilineInput: {
    minHeight: 96,
    textAlignVertical: "top",
    fontFamily: "monospace",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 6,
  },
  buttonRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginTop: 8,
  },
  btnPrimary: {
    backgroundColor: "#5865F2",
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  btnSecondary: {
    backgroundColor: "rgba(255, 255, 255, 0.12)",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  btnDanger: {
    backgroundColor: "#DA373C",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  btnActive: {
    backgroundColor: "#23A55A",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  btnText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "600",
  },
  swatchRow: {
    flexDirection: "row",
    gap: 6,
    marginVertical: 6,
  },
  swatch: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.25)",
  },
  label: {
    color: "#F2F3F5",
    fontSize: 14,
    fontWeight: "600",
  },
  meta: {
    color: "#949BA4",
    fontSize: 12,
    marginTop: 2,
  },
  warningText: {
    color: "#F0B232",
    fontSize: 11,
    marginTop: 4,
  },
});

export default function Settings() {
  initDefaultStorage();
  useProxy(storage);
  const store = storage as unknown as PluginStorage;

  const [urlInput, setUrlInput] = React.useState("");
  const [rawCssInput, setRawCssInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  async function importAndSaveCss(rawCss: string, sourceUrl?: string) {
    const fallbackName = sourceUrl
      ? sourceUrl.split("/").pop()?.replace(/\.theme\.css$|\.css$/i, "") || "Imported Theme"
      : "Pasted CSS Theme";

    const parsed = await parseBdVencordCss(
      rawCss,
      { followImports: store.followImports, maxImportDepth: 3 },
      fallbackName
    );
    const mapped = mapCssThemeToRevenge(parsed, { autoDerive: store.autoDerive });

    const id = `theme_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const entry: SavedThemeEntry = {
      id,
      sourceUrl,
      rawCss,
      theme: mapped.theme,
      stats: mapped.stats,
      warnings: mapped.warnings,
      updatedAt: Date.now(),
    };

    store.themes = [entry, ...store.themes];

    if (store.livePatch) {
      applyLiveTheme(entry.theme, entry.id);
      store.activeThemeId = entry.id;
    }

    showToast(
      `Imported "${entry.theme.name}" (${entry.stats.semanticTokensMapped} tokens mapped)`
    );
  }

  async function handleFetchUrl() {
    const url = urlInput.trim();
    if (!/^https?:\/\//i.test(url)) {
      showToast("Enter a valid http(s) URL to a .theme.css file");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const css = await res.text();
      await importAndSaveCss(css, url);
      setUrlInput("");
    } catch (err: any) {
      showToast(`Fetch failed: ${err?.message || "Network error"}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleImportRaw() {
    const css = rawCssInput.trim();
    if (!css) {
      showToast("Paste BetterDiscord / Vencord CSS first");
      return;
    }
    setLoading(true);
    try {
      await importAndSaveCss(css);
      setRawCssInput("");
    } catch (err: any) {
      showToast(`Parse failed: ${err?.message || "Invalid CSS"}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleToggleTheme(entry: SavedThemeEntry) {
    if (store.activeThemeId === entry.id) {
      clearLiveTheme();
      store.activeThemeId = null;
      showToast(`Deactivated "${entry.theme.name}"`);
      return;
    }
    const state = applyLiveTheme(entry.theme, entry.id);
    store.activeThemeId = entry.id;
    await tryApplyNativeRevengeTheme(entry.theme, entry.id);
    showToast(
      `Applied "${entry.theme.name}" (${state.patchedRawCount} raw + semantic live)`
    );
  }

  function handleCopyJson(entry: SavedThemeEntry) {
    const json = exportRevengeThemeJson(entry.theme);
    try {
      clipboard?.setString?.(json);
      showToast("Copied Revenge spec:2 theme JSON to clipboard");
    } catch {
      showToast("Clipboard unavailable on this build");
    }
  }

  function handleDeleteTheme(id: string) {
    if (store.activeThemeId === id) {
      clearLiveTheme();
      store.activeThemeId = null;
    }
    store.themes = store.themes.filter((t) => t.id !== id);
    showToast("Removed theme");
  }

  return h(
    ScrollView,
    { style: styles.container },
    // Section 1: Import from URL
    h(
      View,
      { style: styles.card },
      h(Text, { style: styles.heading }, "Import Vencord / BetterDiscord Theme URL"),
      h(
        Text,
        { style: styles.subtext },
        "Paste a raw .theme.css URL (GitHub raw, BetterDiscord, Vencord Online Themes, or jsDelivr). @import chains are resolved automatically."
      ),
      h(TextInput, {
        style: styles.input,
        placeholder: "https://raw.githubusercontent.com/.../theme.css",
        placeholderTextColor: "#72767D",
        value: urlInput,
        onChangeText: setUrlInput,
        autoCapitalize: "none",
        autoCorrect: false,
      }),
      h(
        TouchableOpacity,
        { style: styles.btnPrimary, onPress: handleFetchUrl, disabled: loading },
        loading
          ? h(ActivityIndicator, { color: "#FFFFFF" })
          : h(Text, { style: styles.btnText }, "Fetch, Convert & Apply")
      )
    ),

    // Section 2: Paste Raw CSS
    h(
      View,
      { style: styles.card },
      h(Text, { style: styles.heading }, "Or Paste Raw .theme.css"),
      h(TextInput, {
        style: [styles.input, styles.multilineInput],
        placeholder: ":root { --background-primary: #1a1b26; --brand-experiment: #7aa2f7; }",
        placeholderTextColor: "#72767D",
        value: rawCssInput,
        onChangeText: setRawCssInput,
        multiline: true,
        autoCapitalize: "none",
        autoCorrect: false,
      }),
      h(
        TouchableOpacity,
        { style: styles.btnSecondary, onPress: handleImportRaw, disabled: loading },
        h(Text, { style: styles.btnText }, "Convert Pasted CSS")
      )
    ),

    // Section 3: Converter Options
    h(
      View,
      { style: styles.card },
      h(Text, { style: styles.heading }, "Options"),
      h(
        View,
        { style: styles.row },
        h(Text, { style: styles.label }, "Follow @import URLs"),
        h(Switch, {
          value: store.followImports,
          onValueChange: (v: boolean) => {
            store.followImports = v;
          },
        })
      ),
      h(
        View,
        { style: styles.row },
        h(Text, { style: styles.label }, "Auto-derive missing shades"),
        h(Switch, {
          value: store.autoDerive,
          onValueChange: (v: boolean) => {
            store.autoDerive = v;
          },
        })
      ),
      h(
        View,
        { style: styles.row },
        h(Text, { style: styles.label }, "Apply immediately via live patcher"),
        h(Switch, {
          value: store.livePatch,
          onValueChange: (v: boolean) => {
            store.livePatch = v;
          },
        })
      )
    ),

    // Section 4: Saved Themes Library
    h(
      View,
      { style: styles.card },
      h(Text, { style: styles.heading }, `Saved Themes (${store.themes.length})`),
      store.themes.length === 0
        ? h(
            Text,
            { style: styles.subtext },
            "No themes imported yet. Add a Vencord or BetterDiscord .theme.css URL above to get started."
          )
        : store.themes.map((entry) => {
            const isActive = store.activeThemeId === entry.id;
            return h(
              View,
              {
                key: entry.id,
                style: {
                  borderTopWidth: 1,
                  borderTopColor: "rgba(255,255,255,0.08)",
                  paddingTop: 10,
                  marginTop: 10,
                },
              },
              h(Text, { style: styles.label }, entry.theme.name),
              h(
                Text,
                { style: styles.meta },
                `By ${entry.theme.authors?.[0]?.name || "Unknown"} • ${entry.stats.semanticTokensMapped} semantic / ${entry.stats.rawTokensMapped} raw tokens${
                  entry.stats.hasBackground ? " • Wallpaper" : ""
                }`
              ),
              entry.stats.previewSwatches.length > 0
                ? h(
                    View,
                    { style: styles.swatchRow },
                    entry.stats.previewSwatches.map((hex, i) =>
                      h(View, {
                        key: `${entry.id}_sw_${i}`,
                        style: [styles.swatch, { backgroundColor: hex }],
                      })
                    )
                  )
                : null,
              entry.warnings.length > 0
                ? h(Text, { style: styles.warningText }, `Note: ${entry.warnings[0]}`)
                : null,
              h(
                View,
                { style: styles.buttonRow },
                h(
                  TouchableOpacity,
                  {
                    style: isActive ? styles.btnActive : styles.btnPrimary,
                    onPress: () => handleToggleTheme(entry),
                  },
                  h(Text, { style: styles.btnText }, isActive ? "Active (Tap to Disable)" : "Apply")
                ),
                h(
                  TouchableOpacity,
                  {
                    style: styles.btnSecondary,
                    onPress: () => handleCopyJson(entry),
                  },
                  h(Text, { style: styles.btnText }, "Copy JSON")
                ),
                h(
                  TouchableOpacity,
                  {
                    style: styles.btnDanger,
                    onPress: () => handleDeleteTheme(entry.id),
                  },
                  h(Text, { style: styles.btnText }, "Delete")
                )
              )
            );
          })
    )
  );
}

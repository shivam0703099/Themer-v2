/**
 * Maps parsed BetterDiscord / Vencord CSS variables into a Revenge / Vendetta spec:2 Theme JSON.
 * Supports:
 * - Classic Discord CSS variables (--background-primary, --text-normal, --brand-experiment, ...)
 * - 2025/2026 Discord Visual Refresh tokens (--bg-base-primary, --background-base-low, --text-default, ...)
 * - Popular theme frameworks: Midnight (--bg-1..4, --accent-1..5), ClearVision (--main-color, --hover-color),
 *   Material Discord (--main-alt, --chat-color), Catppuccin (--base, --mantle, --crust, --mauve), etc.
 * - Automatic HSL shade derivation when a theme only specifies a handful of core colors.
 */

import { adjustLightness, isLightColor, mixColors, normalizeToHex, withAlpha } from "./colorUtils";
import { ParsedCssTheme } from "./cssParser";

export interface RevengeThemeJson {
  name: string;
  description: string;
  authors: Array<{ name: string; id?: string }>;
  spec: 2;
  semanticColors: Record<string, string[]>;
  rawColors: Record<string, string>;
  background?: {
    url: string;
    alpha?: number;
    blur?: number;
  };
}

export interface MappingResult {
  theme: RevengeThemeJson;
  stats: {
    cssVarsFound: number;
    importsResolved: number;
    semanticTokensMapped: number;
    rawTokensMapped: number;
    hasBackground: boolean;
    previewSwatches: string[];
  };
  warnings: string[];
}

function pickFirstColor(vars: Record<string, string>, keys: string[]): string | null {
  for (const key of keys) {
    const raw = vars[key];
    if (!raw) continue;
    const hex = normalizeToHex(raw, true);
    if (hex) return hex;
  }
  return null;
}

interface CorePalette {
  bgPrimary: string | null;
  bgSecondary: string | null;
  bgSecondaryAlt: string | null;
  bgTertiary: string | null;
  bgFloating: string | null;
  bgAccent: string | null;
  chatBg: string | null;
  inputBg: string | null;
  modHover: string | null;
  modActive: string | null;
  modSelected: string | null;
  modAccent: string | null;
  textNormal: string | null;
  textMuted: string | null;
  headerPrimary: string | null;
  headerSecondary: string | null;
  interactiveNormal: string | null;
  interactiveHover: string | null;
  interactiveActive: string | null;
  interactiveMuted: string | null;
  brand: string | null;
  brandHover: string | null;
  textLink: string | null;
  positive: string | null;
  warning: string | null;
  danger: string | null;
}

function extractCorePalette(vars: Record<string, string>, autoDerive: boolean): CorePalette {
  let bgPrimary = pickFirstColor(vars, [
    "--background-primary",
    "--bg-base-primary",
    "--background-base-low",
    "--bg-4",
    "--main-color",
    "--chat-color",
    "--base",
    "--primary",
    "--background-mobile-primary",
  ]);

  let bgSecondary = pickFirstColor(vars, [
    "--background-secondary",
    "--bg-base-secondary",
    "--background-base-lower",
    "--bg-3",
    "--main-alt",
    "--sidebar-panel-color",
    "--mantle",
    "--secondary",
    "--background-mobile-secondary",
  ]);

  let bgSecondaryAlt = pickFirstColor(vars, [
    "--background-secondary-alt",
    "--background-surface-high",
    "--bg-2",
    "--surface0",
    "--status-picker-color",
  ]);

  let bgTertiary = pickFirstColor(vars, [
    "--background-tertiary",
    "--bg-base-tertiary",
    "--background-base-lowest",
    "--bg-1",
    "--crust",
    "--tertiary",
    "--server-color",
  ]);

  let bgFloating = pickFirstColor(vars, [
    "--background-floating",
    "--bg-surface-overlay",
    "--background-surface-highest",
    "--modal-background",
    "--tooltip-color",
    "--surface1",
  ]);

  let bgAccent = pickFirstColor(vars, [
    "--background-accent",
    "--bg-surface-raised",
    "--background-surface-higher",
    "--surface2",
  ]);

  let chatBg = pickFirstColor(vars, [
    "--chat-background",
    "--chat-background-default",
    "--chat-color",
    "--background-primary",
    "--bg-base-primary",
  ]);

  let inputBg = pickFirstColor(vars, [
    "--channeltextarea-background",
    "--input-background",
    "--bg-2",
    "--surface0",
  ]);

  let brand = pickFirstColor(vars, [
    "--brand-experiment",
    "--brand-500",
    "--accent-2",
    "--accent-1",
    "--accent-new",
    "--accent-color",
    "--accentcolor",
    "--accent",
    "--main-colour",
    "--mauve",
    "--lavender",
    "--blue",
  ]);

  let brandHover = pickFirstColor(vars, [
    "--brand-experiment-560",
    "--brand-560",
    "--hover-color",
    "--accent-3",
    "--accent-4",
    "--accentcolor2",
  ]);

  let textNormal = pickFirstColor(vars, [
    "--text-normal",
    "--text-default",
    "--text-3",
    "--text",
    "--main-text",
  ]);

  let textMuted = pickFirstColor(vars, [
    "--text-muted",
    "--text-subtle",
    "--text-4",
    "--text-5",
    "--subtext0",
  ]);

  let headerPrimary = pickFirstColor(vars, [
    "--header-primary",
    "--text-strong",
    "--text-1",
    "--text-2",
    "--subtext1",
  ]);

  let headerSecondary = pickFirstColor(vars, [
    "--header-secondary",
    "--text-subtle",
    "--text-4",
    "--subtext0",
  ]);

  let interactiveNormal = pickFirstColor(vars, [
    "--interactive-normal",
    "--icon-default",
    "--channels-default",
    "--text-3",
  ]);

  let interactiveHover = pickFirstColor(vars, [
    "--interactive-hover",
    "--icon-strong",
    "--text-2",
  ]);

  let interactiveActive = pickFirstColor(vars, [
    "--interactive-active",
    "--text-1",
    "--header-primary",
  ]);

  let interactiveMuted = pickFirstColor(vars, [
    "--interactive-muted",
    "--icon-muted",
    "--text-5",
  ]);

  let modHover = pickFirstColor(vars, ["--background-modifier-hover", "--hover"]);
  let modActive = pickFirstColor(vars, ["--background-modifier-active", "--active"]);
  let modSelected = pickFirstColor(vars, ["--background-modifier-selected", "--active"]);
  let modAccent = pickFirstColor(vars, ["--background-modifier-accent", "--border-subtle", "--border-light"]);

  let textLink = pickFirstColor(vars, ["--text-link", "--url-color"]);
  let positive = pickFirstColor(vars, ["--text-positive", "--status-positive", "--online", "--green"]);
  let warning = pickFirstColor(vars, ["--text-warning", "--status-warning", "--idle", "--yellow"]);
  let danger = pickFirstColor(vars, ["--text-danger", "--status-danger", "--dnd", "--red"]);

  // If a theme only set --main-color as an accent (e.g. ClearVision), check if bgPrimary is missing
  if (!bgPrimary && bgSecondary) bgPrimary = bgSecondary;
  if (!bgPrimary && bgTertiary) bgPrimary = bgTertiary;

  if (autoDerive) {
    const light = bgPrimary ? isLightColor(bgPrimary) : false;
    const step = light ? -4 : 4;

    if (bgPrimary) {
      if (!bgSecondary) bgSecondary = adjustLightness(bgPrimary, -step * 0.75);
      if (!bgSecondaryAlt) bgSecondaryAlt = adjustLightness(bgPrimary, -step * 1.1);
      if (!bgTertiary) bgTertiary = adjustLightness(bgPrimary, -step * 1.5);
      if (!bgFloating) bgFloating = adjustLightness(bgPrimary, -step * 1.8);
      if (!bgAccent) bgAccent = adjustLightness(bgPrimary, step * 2.0);
      if (!chatBg) chatBg = bgPrimary;
      if (!inputBg) inputBg = adjustLightness(bgPrimary, step * 1.2);
      if (!modHover) modHover = withAlpha(adjustLightness(bgPrimary, step * 4), 0.35);
      if (!modActive) modActive = withAlpha(adjustLightness(bgPrimary, step * 5), 0.5);
      if (!modSelected) modSelected = withAlpha(brand || adjustLightness(bgPrimary, step * 5), 0.25);
      if (!modAccent) modAccent = withAlpha(adjustLightness(bgPrimary, step * 6), 0.3);
    }

    if (brand) {
      if (!brandHover) brandHover = adjustLightness(brand, -8);
      if (!textLink) textLink = adjustLightness(brand, light ? -8 : 10);
    }

    if (textNormal) {
      if (!headerPrimary) headerPrimary = adjustLightness(textNormal, light ? -8 : 8);
      if (!headerSecondary) headerSecondary = adjustLightness(textNormal, light ? 12 : -15);
      if (!textMuted) textMuted = adjustLightness(textNormal, light ? 20 : -25);
      if (!interactiveNormal) interactiveNormal = adjustLightness(textNormal, light ? 8 : -10);
      if (!interactiveHover) interactiveHover = headerPrimary;
      if (!interactiveActive) interactiveActive = headerPrimary;
      if (!interactiveMuted) interactiveMuted = adjustLightness(textNormal, light ? 30 : -40);
    }
  }

  return {
    bgPrimary,
    bgSecondary,
    bgSecondaryAlt,
    bgTertiary,
    bgFloating,
    bgAccent,
    chatBg,
    inputBg,
    modHover,
    modActive,
    modSelected,
    modAccent,
    textNormal,
    textMuted,
    headerPrimary,
    headerSecondary,
    interactiveNormal,
    interactiveHover,
    interactiveActive,
    interactiveMuted,
    brand,
    brandHover,
    textLink,
    positive,
    warning,
    danger,
  };
}

/**
 * Convert a ParsedCssTheme into a Revenge spec:2 JSON theme.
 */
export function mapCssThemeToRevenge(
  parsed: ParsedCssTheme,
  options: { autoDerive?: boolean } = {}
): MappingResult {
  const autoDerive = options.autoDerive !== false;
  const dark = extractCorePalette(parsed.darkVars, autoDerive);
  const hasLightOverrides = Object.keys(parsed.lightVars).some(
    (k) => parsed.lightVars[k] !== parsed.darkVars[k]
  );
  const light = hasLightOverrides ? extractCorePalette(parsed.lightVars, autoDerive) : dark;

  const semanticColors: Record<string, string[]> = {};
  const rawColors: Record<string, string> = {};

  function setSemantic(token: string, darkVal: string | null, lightVal: string | null) {
    if (!darkVal && !lightVal) return;
    const d = darkVal || lightVal!;
    const l = lightVal || darkVal!;
    semanticColors[token] = [d, l];
  }

  function setRaw(token: string, val: string | null) {
    if (val) rawColors[token] = val;
  }

  // --- Classic Discord Mobile Semantic Tokens ---
  setSemantic("BACKGROUND_PRIMARY", dark.bgPrimary, light.bgPrimary);
  setSemantic("BACKGROUND_SECONDARY", dark.bgSecondary, light.bgSecondary);
  setSemantic("BACKGROUND_SECONDARY_ALT", dark.bgSecondaryAlt, light.bgSecondaryAlt);
  setSemantic("BACKGROUND_TERTIARY", dark.bgTertiary, light.bgTertiary);
  setSemantic("BACKGROUND_ACCENT", dark.bgAccent, light.bgAccent);
  setSemantic("BACKGROUND_FLOATING", dark.bgFloating, light.bgFloating);
  setSemantic("BACKGROUND_NESTED_FLOATING", dark.bgSecondary, light.bgSecondary);
  setSemantic("BACKGROUND_MOBILE_PRIMARY", dark.bgPrimary, light.bgPrimary);
  setSemantic("BACKGROUND_MOBILE_SECONDARY", dark.bgSecondary, light.bgSecondary);
  setSemantic("BACKGROUND_MODIFIER_HOVER", dark.modHover, light.modHover);
  setSemantic("BACKGROUND_MODIFIER_ACTIVE", dark.modActive, light.modActive);
  setSemantic("BACKGROUND_MODIFIER_SELECTED", dark.modSelected, light.modSelected);
  setSemantic("BACKGROUND_MODIFIER_ACCENT", dark.modAccent, light.modAccent);
  setSemantic("CHAT_BACKGROUND", dark.chatBg, light.chatBg);
  setSemantic("CHAT_INPUT_CONTAINER_BACKGROUND", dark.inputBg, light.inputBg);
  setSemantic("INPUT_BACKGROUND", dark.inputBg, light.inputBg);
  setSemantic("CARD_PRIMARY_BG", dark.bgSecondary, light.bgSecondary);
  setSemantic("CARD_SECONDARY_BG", dark.bgSecondaryAlt, light.bgSecondaryAlt);
  setSemantic("SPOILER_HIDDEN_BACKGROUND", dark.bgTertiary, light.bgTertiary);
  setSemantic("SPOILER_REVEALED_BACKGROUND", dark.bgSecondaryAlt, light.bgSecondaryAlt);
  setSemantic("BORDER_SUBTLE", dark.modAccent, light.modAccent);
  setSemantic("BORDER_STRONG", dark.modActive, light.modActive);
  setSemantic("BORDER_FAINT", dark.modHover, light.modHover);

  // --- Discord 2025/2026 Mobile Visual Refresh Semantic Tokens ---
  setSemantic("BG_BASE_PRIMARY", dark.bgPrimary, light.bgPrimary);
  setSemantic("BG_BASE_SECONDARY", dark.bgSecondary, light.bgSecondary);
  setSemantic("BG_BASE_TERTIARY", dark.bgTertiary, light.bgTertiary);
  setSemantic("BG_BACKDROP", dark.bgTertiary, light.bgTertiary);
  setSemantic("BG_SURFACE_RAISED", dark.bgAccent, light.bgAccent);
  setSemantic("BG_SURFACE_OVERLAY", dark.bgFloating, light.bgFloating);
  setSemantic("BACKGROUND_BASE_LOW", dark.bgPrimary, light.bgPrimary);
  setSemantic("BACKGROUND_BASE_LOWER", dark.bgSecondary, light.bgSecondary);
  setSemantic("BACKGROUND_BASE_LOWEST", dark.bgTertiary, light.bgTertiary);
  setSemantic("BACKGROUND_SURFACE_HIGH", dark.bgSecondaryAlt, light.bgSecondaryAlt);
  setSemantic("BACKGROUND_SURFACE_HIGHER", dark.bgAccent, light.bgAccent);
  setSemantic("BACKGROUND_SURFACE_HIGHEST", dark.bgFloating, light.bgFloating);

  // --- Typography & Icons ---
  setSemantic("HEADER_PRIMARY", dark.headerPrimary, light.headerPrimary);
  setSemantic("HEADER_SECONDARY", dark.headerSecondary, light.headerSecondary);
  setSemantic("TEXT_NORMAL", dark.textNormal, light.textNormal);
  setSemantic("TEXT_DEFAULT", dark.textNormal, light.textNormal);
  setSemantic("TEXT_STRONG", dark.headerPrimary, light.headerPrimary);
  setSemantic("TEXT_SUBTLE", dark.textMuted, light.textMuted);
  setSemantic("TEXT_MUTED", dark.textMuted, light.textMuted);
  setSemantic("TEXT_LINK", dark.textLink, light.textLink);
  setSemantic("TEXT_BRAND", dark.brand, light.brand);
  setSemantic("TEXT_POSITIVE", dark.positive, light.positive);
  setSemantic("TEXT_WARNING", dark.warning, light.warning);
  setSemantic("TEXT_DANGER", dark.danger, light.danger);

  setSemantic("INTERACTIVE_NORMAL", dark.interactiveNormal, light.interactiveNormal);
  setSemantic("INTERACTIVE_HOVER", dark.interactiveHover, light.interactiveHover);
  setSemantic("INTERACTIVE_ACTIVE", dark.interactiveActive, light.interactiveActive);
  setSemantic("INTERACTIVE_MUTED", dark.interactiveMuted, light.interactiveMuted);
  setSemantic("ICON_DEFAULT", dark.interactiveNormal, light.interactiveNormal);
  setSemantic("ICON_STRONG", dark.interactiveActive, light.interactiveActive);
  setSemantic("ICON_MUTED", dark.interactiveMuted, light.interactiveMuted);
  setSemantic("CHANNELS_DEFAULT", dark.interactiveNormal, light.interactiveNormal);
  setSemantic("CHANNEL_ICON", dark.interactiveMuted || dark.interactiveNormal, light.interactiveMuted || light.interactiveNormal);
  setSemantic("REDESIGN_CHANNEL_CATEGORY_NAME_TEXT", dark.headerSecondary, light.headerSecondary);
  setSemantic("REDESIGN_BUTTON_PRIMARY_BACKGROUND", dark.brand, light.brand);
  setSemantic("REDESIGN_BUTTON_PRIMARY_PRESSED_BACKGROUND", dark.brandHover, light.brandHover);
  setSemantic("REDESIGN_BUTTON_SECONDARY_BACKGROUND", dark.bgSecondaryAlt, light.bgSecondaryAlt);
  setSemantic("STATUS_POSITIVE", dark.positive, light.positive);
  setSemantic("STATUS_WARNING", dark.warning, light.warning);
  setSemantic("STATUS_DANGER", dark.danger, light.danger);

  // --- RawColors (critical for Discord Mobile components that read RawColor directly) ---
  setRaw("PRIMARY_600", dark.bgPrimary);
  setRaw("PRIMARY_630", dark.bgSecondary);
  setRaw("PRIMARY_660", dark.bgSecondaryAlt);
  setRaw("PRIMARY_700", dark.bgTertiary);
  setRaw("PRIMARY_800", dark.bgFloating);
  setRaw("PRIMARY_500", dark.bgAccent);
  setRaw("PRIMARY_400", dark.textMuted);
  setRaw("PRIMARY_300", dark.interactiveNormal);
  setRaw("PRIMARY_200", dark.textNormal);
  setRaw("PRIMARY_100", dark.headerPrimary);

  // Discord Mobile dark/midnight PLUM palette tokens
  setRaw("PLUM_16", dark.bgAccent);
  setRaw("PLUM_17", dark.bgSecondaryAlt);
  setRaw("PLUM_18", dark.bgPrimary);
  setRaw("PLUM_19", dark.bgSecondary);
  setRaw("PLUM_20", dark.bgSecondary);
  setRaw("PLUM_21", dark.bgTertiary);
  setRaw("PLUM_22", dark.bgTertiary);
  setRaw("PLUM_23", dark.bgFloating);
  setRaw("PLUM_24", dark.bgFloating);

  if (dark.brand) {
    setRaw("BRAND_500", dark.brand);
    setRaw("BRAND_560", dark.brandHover || adjustLightness(dark.brand, -8));
    setRaw("BRAND_400", adjustLightness(dark.brand, 10));
    setRaw("BRAND_360", adjustLightness(dark.brand, 15));
    setRaw("BRAND_600", adjustLightness(dark.brand, -14));
    if (dark.bgPrimary) {
      setRaw("BRAND_260", mixColors(dark.brand, dark.bgPrimary, 0.35));
    }
  }
  setRaw("GREEN_360", dark.positive);
  setRaw("YELLOW_300", dark.warning);
  setRaw("RED_400", dark.danger);

  const theme: RevengeThemeJson = {
    name: parsed.metadata.name,
    description: parsed.metadata.description,
    authors: [{ name: parsed.metadata.author }],
    spec: 2,
    semanticColors,
    rawColors,
  };

  if (parsed.backgroundUrl) {
    theme.background = {
      url: parsed.backgroundUrl,
      alpha: parsed.backgroundAlpha,
      blur: parsed.backgroundBlur,
    };
  }

  const previewSwatches = [
    dark.bgPrimary,
    dark.bgSecondary,
    dark.bgTertiary,
    dark.brand,
    dark.textNormal,
  ].filter((c): c is string => Boolean(c));

  const warnings = [...parsed.warnings];
  if (Object.keys(semanticColors).length === 0 && !theme.background) {
    warnings.push(
      "No recognized color variables were found in this CSS. It may rely exclusively on desktop DOM selectors, which React Native cannot execute."
    );
  }

  return {
    theme,
    stats: {
      cssVarsFound: Object.keys(parsed.allVars).length,
      importsResolved: parsed.importedUrls.length,
      semanticTokensMapped: Object.keys(semanticColors).length,
      rawTokensMapped: Object.keys(rawColors).length,
      hasBackground: Boolean(theme.background),
      previewSwatches,
    },
    warnings,
  };
}

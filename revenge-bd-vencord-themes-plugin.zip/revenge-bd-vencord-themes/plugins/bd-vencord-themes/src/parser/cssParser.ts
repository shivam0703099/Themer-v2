/**
 * BetterDiscord & Vencord (.theme.css) Parser
 * - Extracts BD/Vencord JSDoc metadata (@name, @author, @description, @version, @source)
 * - Recursively fetches and inlines @import url(...) stylesheets (with cycle & depth protection)
 * - Parses CSS custom properties (--var: value) scoped by :root / dark / light selectors
 * - Resolves nested var(--foo, fallback) references and calc()/rgb(var(--x)) expressions
 * - Extracts background wallpaper URLs and blur/alpha hints
 */

export interface ThemeMetadata {
  name: string;
  author: string;
  description: string;
  version: string;
  source?: string;
}

export interface ParsedCssTheme {
  metadata: ThemeMetadata;
  darkVars: Record<string, string>;
  lightVars: Record<string, string>;
  allVars: Record<string, string>;
  backgroundUrl: string | null;
  backgroundBlur: number;
  backgroundAlpha: number;
  importedUrls: string[];
  warnings: string[];
}

export interface FetchCssOptions {
  followImports?: boolean;
  maxImportDepth?: number;
  fetcher?: (url: string) => Promise<string>;
}

/**
 * Parse BetterDiscord / Vencord header metadata from the leading JSDoc block.
 */
export function parseThemeMetadata(css: string, fallbackName = "Imported CSS Theme"): ThemeMetadata {
  const meta: ThemeMetadata = {
    name: fallbackName,
    author: "Unknown",
    description: "Converted from BetterDiscord / Vencord CSS theme.",
    version: "1.0.0",
  };

  const headerMatch = css.match(/\/\*\*([\s\S]*?)\*\//);
  if (!headerMatch) return meta;

  const lines = headerMatch[1].split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine.replace(/^\s*\*\s?/, "").trim();
    const tagMatch = line.match(/^@([a-zA-Z0-9_-]+)\s+(.+)$/);
    if (!tagMatch) continue;
    const key = tagMatch[1].toLowerCase();
    const val = tagMatch[2].trim();
    if (key === "name") meta.name = val;
    else if (key === "author") meta.author = val;
    else if (key === "description") meta.description = val;
    else if (key === "version") meta.version = val;
    else if (key === "source" || key === "website") meta.source = val;
  }
  return meta;
}

/**
 * Extract @import URLs from CSS text.
 */
export function extractImportUrls(css: string): string[] {
  const urls: string[] = [];
  const regex = /@import\s+(?:url\(\s*(['"]?)([^)'"]+)\1\s*\)|(['"])([^'"]+)\3)[^;]*;/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(css)) !== null) {
    const url = (match[2] || match[4] || "").trim();
    if (url && /^https?:\/\//i.test(url)) {
      urls.push(url);
    }
  }
  return urls;
}

/**
 * Strip CSS comments while keeping string literals intact.
 */
export function stripCssComments(css: string): string {
  return css.replace(/\/\*[\s\S]*?\*\//g, "");
}

/**
 * Default HTTP fetcher compatible with React Native / Hermes & Node 18+.
 */
async function defaultFetcher(url: string): Promise<string> {
  const res = await fetch(url, {
    headers: { Accept: "text/css,text/plain,*/*" },
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} fetching ${url}`);
  }
  return await res.text();
}

/**
 * Recursively resolve @import statements so base themes (e.g. Midnight, ClearVision, Catppuccin)
 * are parsed BEFORE the user's overrides in the main .theme.css file.
 */
export async function resolveCssWithImports(
  css: string,
  options: FetchCssOptions = {},
  _depth = 0,
  _visited: Set<string> = new Set(),
  _importedUrls: string[] = [],
  _warnings: string[] = []
): Promise<{ combinedCss: string; importedUrls: string[]; warnings: string[] }> {
  const followImports = options.followImports !== false;
  const maxDepth = options.maxImportDepth ?? 3;
  const fetcher = options.fetcher ?? defaultFetcher;

  if (!followImports || _depth >= maxDepth) {
    return { combinedCss: css, importedUrls: _importedUrls, warnings: _warnings };
  }

  const imports = extractImportUrls(stripCssComments(css));
  const importedChunks: string[] = [];

  for (const url of imports) {
    if (_visited.has(url)) continue;
    _visited.add(url);
    try {
      const subCss = await fetcher(url);
      _importedUrls.push(url);
      const subResolved = await resolveCssWithImports(
        subCss,
        options,
        _depth + 1,
        _visited,
        _importedUrls,
        _warnings
      );
      importedChunks.push(subResolved.combinedCss);
    } catch (err: any) {
      _warnings.push(`Failed @import (${url}): ${err?.message || String(err)}`);
    }
  }

  // Imported base rules come first so the main theme's overrides win
  const combinedCss = [...importedChunks, css].join("\n\n");
  return { combinedCss, importedUrls: _importedUrls, warnings: _warnings };
}

/**
 * Resolve var(--name, fallback) references inside a CSS value string.
 */
export function resolveCssVarValue(
  rawValue: string,
  vars: Record<string, string>,
  depth = 0
): string {
  if (!rawValue || depth > 8 || !rawValue.includes("var(")) {
    return rawValue.trim();
  }

  let result = "";
  let i = 0;
  while (i < rawValue.length) {
    const idx = rawValue.indexOf("var(", i);
    if (idx === -1) {
      result += rawValue.slice(i);
      break;
    }
    result += rawValue.slice(i, idx);

    // Find matching closing parenthesis
    let parenDepth = 1;
    let j = idx + 4;
    while (j < rawValue.length && parenDepth > 0) {
      if (rawValue[j] === "(") parenDepth++;
      else if (rawValue[j] === ")") parenDepth--;
      j++;
    }
    const inner = rawValue.slice(idx + 4, j - 1).trim();

    // Split on first top-level comma for fallback
    let commaIdx = -1;
    let innerDepth = 0;
    for (let k = 0; k < inner.length; k++) {
      if (inner[k] === "(") innerDepth++;
      else if (inner[k] === ")") innerDepth--;
      else if (inner[k] === "," && innerDepth === 0) {
        commaIdx = k;
        break;
      }
    }

    const varName = (commaIdx === -1 ? inner : inner.slice(0, commaIdx)).trim();
    const fallback = commaIdx === -1 ? "" : inner.slice(commaIdx + 1).trim();

    const replacement = vars[varName];
    if (replacement !== undefined) {
      result += resolveCssVarValue(replacement, vars, depth + 1);
    } else if (fallback) {
      result += resolveCssVarValue(fallback, vars, depth + 1);
    } else {
      result += `var(${inner})`;
    }
    i = j;
  }

  return result.trim();
}

/**
 * Extract the first valid http(s) URL inside url(...) from a CSS value.
 */
function extractHttpUrl(value: string): string | null {
  const m = value.match(/url\(\s*(['"]?)(https?:\/\/[^)'"]+)\1\s*\)/i);
  return m ? m[2].trim() : null;
}

/**
 * Parse CSS blocks and extract custom properties (--*) categorized by dark vs light mode.
 */
export function parseCssVariables(css: string): {
  darkVars: Record<string, string>;
  lightVars: Record<string, string>;
  allVars: Record<string, string>;
  backgroundUrl: string | null;
  backgroundBlur: number;
  backgroundAlpha: number;
} {
  const clean = stripCssComments(css);
  const rootVars: Record<string, string> = {};
  const darkVars: Record<string, string> = {};
  const lightVars: Record<string, string> = {};
  let detectedBgUrl: string | null = null;

  // Walk top-level and nested blocks safely
  let i = 0;
  const len = clean.length;

  function parseBlock(selector: string, body: string) {
    const sel = selector.toLowerCase();
    const isLight = sel.includes(".theme-light");
    const isDark =
      sel.includes(".theme-dark") ||
      sel.includes(".theme-darker") ||
      sel.includes(".theme-midnight") ||
      sel.includes(".visual-refresh");
    const isRoot = sel.includes(":root") || sel.includes("body") || sel.includes("#app-mount") || sel === "*";

    // Extract custom properties --foo: bar;
    const declRegex = /(--[a-zA-Z0-9_-]+)\s*:\s*([^;{}]+?)(?:;|$)/g;
    let m: RegExpExecArray | null;
    while ((m = declRegex.exec(body)) !== null) {
      const name = m[1].trim();
      const val = m[2].replace(/\s*!important\s*$/i, "").trim();
      if (!val) continue;

      if (isLight && !isDark) {
        lightVars[name] = val;
      } else if (isDark && !isLight) {
        darkVars[name] = val;
      } else if (isRoot || (!isLight && !isDark)) {
        rootVars[name] = val;
      } else {
        // Both .theme-dark and .theme-light listed together
        darkVars[name] = val;
        lightVars[name] = val;
      }
    }

    // Look for direct background-image: url(...) on app containers
    if (
      sel.includes("body") ||
      sel.includes("#app-mount") ||
      sel.includes(".app") ||
      sel.includes(".bg_") ||
      sel.includes("chat")
    ) {
      const bgMatch = body.match(/background(?:-image)?\s*:\s*([^;{}]+)/i);
      if (bgMatch) {
        const url = extractHttpUrl(bgMatch[1]);
        if (url) detectedBgUrl = url;
      }
    }
  }

  while (i < len) {
    const braceOpen = clean.indexOf("{", i);
    if (braceOpen === -1) break;
    const selector = clean.slice(i, braceOpen).trim();

    // Find matching closing brace
    let depth = 1;
    let j = braceOpen + 1;
    while (j < len && depth > 0) {
      if (clean[j] === "{") depth++;
      else if (clean[j] === "}") depth--;
      j++;
    }
    const body = clean.slice(braceOpen + 1, j - 1);

    // Unwrap @media / @supports blocks recursively
    if (/^@(?:media|supports|layer)/i.test(selector)) {
      const inner = parseCssVariables(body);
      Object.assign(rootVars, inner.allVars);
      Object.assign(darkVars, inner.darkVars);
      Object.assign(lightVars, inner.lightVars);
      if (inner.backgroundUrl) detectedBgUrl = inner.backgroundUrl;
    } else if (!selector.startsWith("@")) {
      parseBlock(selector, body);
    }

    i = j;
  }

  const mergedDark: Record<string, string> = { ...rootVars, ...darkVars };
  const mergedLight: Record<string, string> = { ...rootVars, ...lightVars };
  const mergedAll: Record<string, string> = { ...rootVars, ...lightVars, ...darkVars };

  // Resolve all var() references
  const resolvedDark: Record<string, string> = {};
  const resolvedLight: Record<string, string> = {};
  const resolvedAll: Record<string, string> = {};

  for (const [k, v] of Object.entries(mergedDark)) {
    resolvedDark[k] = resolveCssVarValue(v, mergedDark);
  }
  for (const [k, v] of Object.entries(mergedLight)) {
    resolvedLight[k] = resolveCssVarValue(v, mergedLight);
  }
  for (const [k, v] of Object.entries(mergedAll)) {
    resolvedAll[k] = resolveCssVarValue(v, mergedAll);
  }

  // Check well-known BD/Vencord background image variables
  const bgVarCandidates = [
    "--background-image",
    "--app-bg",
    "--bg-image",
    "--background",
    "--home-image",
    "--backdrop-image",
    "--background-tertiary-alt",
    "--custom-background",
  ];
  for (const key of bgVarCandidates) {
    const val = resolvedDark[key] || resolvedAll[key];
    if (val) {
      const url = extractHttpUrl(val);
      if (url) {
        detectedBgUrl = url;
        break;
      }
    }
  }

  // Extract optional blur / alpha hints
  let backgroundBlur = 0;
  const blurRaw = resolvedDark["--background-blur"] || resolvedDark["--background-image-blur"] || "";
  const blurNum = parseFloat(blurRaw);
  if (!isNaN(blurNum) && blurNum >= 0) {
    backgroundBlur = Math.min(1, blurNum > 1 ? blurNum / 20 : blurNum);
  }

  let backgroundAlpha = 0.85;
  const shadingRaw = resolvedDark["--background-shading"] || resolvedDark["--background-opacity"] || "";
  if (shadingRaw) {
    const n = parseFloat(shadingRaw);
    if (!isNaN(n)) {
      backgroundAlpha = shadingRaw.includes("%") ? Math.min(1, Math.max(0.1, n / 100)) : Math.min(1, Math.max(0.1, n));
    }
  }

  return {
    darkVars: resolvedDark,
    lightVars: resolvedLight,
    allVars: resolvedAll,
    backgroundUrl: detectedBgUrl,
    backgroundBlur,
    backgroundAlpha,
  };
}

/**
 * Full end-to-end parse pipeline: metadata + @import resolution + variable extraction.
 */
export async function parseBdVencordCss(
  rawCss: string,
  options: FetchCssOptions = {},
  fallbackName = "Imported CSS Theme"
): Promise<ParsedCssTheme> {
  const metadata = parseThemeMetadata(rawCss, fallbackName);
  const { combinedCss, importedUrls, warnings } = await resolveCssWithImports(rawCss, options);
  const parsed = parseCssVariables(combinedCss);

  return {
    metadata,
    darkVars: parsed.darkVars,
    lightVars: parsed.lightVars,
    allVars: parsed.allVars,
    backgroundUrl: parsed.backgroundUrl,
    backgroundBlur: parsed.backgroundBlur,
    backgroundAlpha: parsed.backgroundAlpha,
    importedUrls,
    warnings,
  };
}

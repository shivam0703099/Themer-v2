/**
 * CSS Color Parser & Manipulation Utilities (Hermes / React Native safe, zero deps)
 * Supports: #RGB, #RGBA, #RRGGBB, #RRGGBBAA, rgb(), rgba(), hsl(), hsla(),
 * space-separated CSS Color 4 syntax (rgb(r g b / a), hsl(h s% l% / a)),
 * common CSS named colors, and HSL shade derivation.
 */

export interface RGBA {
  r: number; // 0-255
  g: number; // 0-255
  b: number; // 0-255
  a: number; // 0-1
}

export interface HSL {
  h: number; // 0-360
  s: number; // 0-100
  l: number; // 0-100
  a: number; // 0-1
}

const NAMED_COLORS: Record<string, string> = {
  black: "#000000",
  white: "#ffffff",
  red: "#ff0000",
  green: "#008000",
  blue: "#0000ff",
  yellow: "#ffff00",
  cyan: "#00ffff",
  aqua: "#00ffff",
  magenta: "#ff00ff",
  fuchsia: "#ff00ff",
  gray: "#808080",
  grey: "#808080",
  darkgray: "#a9a9a9",
  darkgrey: "#a9a9a9",
  lightgray: "#d3d3d3",
  lightgrey: "#d3d3d3",
  silver: "#c0c0c0",
  maroon: "#800000",
  olive: "#808000",
  lime: "#00ff00",
  teal: "#008080",
  navy: "#000080",
  purple: "#800080",
  orange: "#ffa500",
  pink: "#ffc0cb",
  indigo: "#4b0082",
  violet: "#ee82ee",
  crimson: "#dc143c",
  coral: "#ff7f50",
  gold: "#ffd700",
  transparent: "#00000000",
};

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

function parseAlpha(raw: string | undefined): number {
  if (!raw) return 1;
  const s = raw.trim();
  if (s.endsWith("%")) {
    const n = parseFloat(s.slice(0, -1));
    return isNaN(n) ? 1 : clamp(n / 100, 0, 1);
  }
  const n = parseFloat(s);
  return isNaN(n) ? 1 : clamp(n, 0, 1);
}

function parseRgbChannel(raw: string): number {
  const s = raw.trim();
  if (s.endsWith("%")) {
    const n = parseFloat(s.slice(0, -1));
    return isNaN(n) ? 0 : clamp(Math.round((n / 100) * 255), 0, 255);
  }
  const n = parseFloat(s);
  return isNaN(n) ? 0 : clamp(Math.round(n), 0, 255);
}

export function hslToRgba(h: number, s: number, l: number, a = 1): RGBA {
  const hue = ((h % 360) + 360) % 360;
  const sat = clamp(s, 0, 100) / 100;
  const lig = clamp(l, 0, 100) / 100;

  const c = (1 - Math.abs(2 * lig - 1)) * sat;
  const x = c * (1 - Math.abs(((hue / 60) % 2) - 1));
  const m = lig - c / 2;

  let r1 = 0, g1 = 0, b1 = 0;
  if (hue < 60) {
    r1 = c; g1 = x; b1 = 0;
  } else if (hue < 120) {
    r1 = x; g1 = c; b1 = 0;
  } else if (hue < 180) {
    r1 = 0; g1 = c; b1 = x;
  } else if (hue < 240) {
    r1 = 0; g1 = x; b1 = c;
  } else if (hue < 300) {
    r1 = x; g1 = 0; b1 = c;
  } else {
    r1 = c; g1 = 0; b1 = x;
  }

  return {
    r: clamp(Math.round((r1 + m) * 255), 0, 255),
    g: clamp(Math.round((g1 + m) * 255), 0, 255),
    b: clamp(Math.round((b1 + m) * 255), 0, 255),
    a: clamp(a, 0, 1),
  };
}

export function rgbaToHsl(c: RGBA): HSL {
  const r = c.r / 255;
  const g = c.g / 255;
  const b = c.b / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  const l = (max + min) / 2;

  let h = 0;
  let s = 0;
  if (d !== 0) {
    s = d / (1 - Math.abs(2 * l - 1));
    switch (max) {
      case r:
        h = 60 * (((g - b) / d) % 6);
        break;
      case g:
        h = 60 * ((b - r) / d + 2);
        break;
      case b:
        h = 60 * ((r - g) / d + 4);
        break;
    }
  }
  if (h < 0) h += 360;
  return { h, s: s * 100, l: l * 100, a: c.a };
}

/**
 * Parse a CSS color string into an RGBA object, or null if not a valid color.
 * Also handles bare "r, g, b" triplets commonly used in BD/Vencord themes (e.g. --accentcolor: 88, 101, 242).
 */
export function parseCssColor(input: string): RGBA | null {
  if (!input || typeof input !== "string") return null;
  let s = input.trim().replace(/\s*!important\s*$/i, "").trim();
  if (!s) return null;

  const lower = s.toLowerCase();
  if (NAMED_COLORS[lower]) {
    s = NAMED_COLORS[lower];
  }

  // Hex: #RGB, #RGBA, #RRGGBB, #RRGGBBAA
  if (s.startsWith("#")) {
    const hex = s.slice(1);
    if (hex.length === 3 || hex.length === 4) {
      const r = parseInt(hex[0] + hex[0], 16);
      const g = parseInt(hex[1] + hex[1], 16);
      const b = parseInt(hex[2] + hex[2], 16);
      const a = hex.length === 4 ? parseInt(hex[3] + hex[3], 16) / 255 : 1;
      if ([r, g, b].some(isNaN) || isNaN(a)) return null;
      return { r, g, b, a };
    }
    if (hex.length === 6 || hex.length === 8) {
      const r = parseInt(hex.slice(0, 2), 16);
      const g = parseInt(hex.slice(2, 4), 16);
      const b = parseInt(hex.slice(4, 6), 16);
      const a = hex.length === 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1;
      if ([r, g, b].some(isNaN) || isNaN(a)) return null;
      return { r, g, b, a };
    }
    return null;
  }

  // rgb() / rgba()
  const rgbMatch = s.match(/^rgba?\(\s*([^)]+)\s*\)$/i);
  if (rgbMatch) {
    const body = rgbMatch[1].trim();
    let parts: string[];
    let alphaPart: string | undefined;
    if (body.includes("/")) {
      const [left, right] = body.split("/");
      parts = left.trim().split(/[\s,]+/).filter(Boolean);
      alphaPart = right;
    } else {
      parts = body.split(/[\s,]+/).filter(Boolean);
      if (parts.length >= 4) alphaPart = parts[3];
    }
    if (parts.length < 3) return null;
    return {
      r: parseRgbChannel(parts[0]),
      g: parseRgbChannel(parts[1]),
      b: parseRgbChannel(parts[2]),
      a: parseAlpha(alphaPart),
    };
  }

  // hsl() / hsla()
  const hslMatch = s.match(/^hsla?\(\s*([^)]+)\s*\)$/i);
  if (hslMatch) {
    const body = hslMatch[1].trim();
    let parts: string[];
    let alphaPart: string | undefined;
    if (body.includes("/")) {
      const [left, right] = body.split("/");
      parts = left.trim().split(/[\s,]+/).filter(Boolean);
      alphaPart = right;
    } else {
      parts = body.split(/[\s,]+/).filter(Boolean);
      if (parts.length >= 4) alphaPart = parts[3];
    }
    if (parts.length < 3) return null;
    let h = parseFloat(parts[0]);
    if (parts[0].endsWith("turn")) h *= 360;
    else if (parts[0].endsWith("rad")) h *= 180 / Math.PI;
    else if (parts[0].endsWith("grad")) h *= 0.9;
    const sat = parseFloat(parts[1]);
    const lig = parseFloat(parts[2]);
    if ([h, sat, lig].some(isNaN)) return null;
    return hslToRgba(h, sat, lig, parseAlpha(alphaPart));
  }

  // Bare RGB triplet used by many BetterDiscord themes (e.g. "88, 101, 242")
  const tripletMatch = s.match(/^(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})$/);
  if (tripletMatch) {
    return {
      r: clamp(parseInt(tripletMatch[1], 10), 0, 255),
      g: clamp(parseInt(tripletMatch[2], 10), 0, 255),
      b: clamp(parseInt(tripletMatch[3], 10), 0, 255),
      a: 1,
    };
  }

  return null;
}

function toHexByte(n: number): string {
  return clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0").toUpperCase();
}

export function rgbaToHex(c: RGBA, includeAlpha = true): string {
  const base = `#${toHexByte(c.r)}${toHexByte(c.g)}${toHexByte(c.b)}`;
  if (!includeAlpha || c.a >= 0.996) return base;
  return `${base}${toHexByte(c.a * 255)}`;
}

export function normalizeToHex(input: string, includeAlpha = true): string | null {
  const parsed = parseCssColor(input);
  return parsed ? rgbaToHex(parsed, includeAlpha) : null;
}

export function adjustLightness(hexOrCss: string, deltaL: number, alphaOverride?: number): string {
  const parsed = parseCssColor(hexOrCss);
  if (!parsed) return hexOrCss;
  const hsl = rgbaToHsl(parsed);
  const next = hslToRgba(
    hsl.h,
    hsl.s,
    clamp(hsl.l + deltaL, 0, 100),
    alphaOverride !== undefined ? clamp(alphaOverride, 0, 1) : hsl.a
  );
  return rgbaToHex(next, true);
}

export function withAlpha(hexOrCss: string, alpha: number): string {
  const parsed = parseCssColor(hexOrCss);
  if (!parsed) return hexOrCss;
  return rgbaToHex({ ...parsed, a: clamp(alpha, 0, 1) }, true);
}

export function isLightColor(hexOrCss: string): boolean {
  const parsed = parseCssColor(hexOrCss);
  if (!parsed) return false;
  // Relative luminance heuristic
  const lum = (0.299 * parsed.r + 0.587 * parsed.g + 0.114 * parsed.b) / 255;
  return lum > 0.55;
}

export function mixColors(colorA: string, colorB: string, weightB = 0.5): string {
  const a = parseCssColor(colorA);
  const b = parseCssColor(colorB);
  if (!a) return colorB;
  if (!b) return colorA;
  const w = clamp(weightB, 0, 1);
  return rgbaToHex({
    r: a.r * (1 - w) + b.r * w,
    g: a.g * (1 - w) + b.g * w,
    b: a.b * (1 - w) + b.b * w,
    a: a.a * (1 - w) + b.a * w,
  });
}
